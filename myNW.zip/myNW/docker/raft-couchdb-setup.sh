#!/bin/bash
# Usage:  ./init-setup.sh [tls]
# If the $1 = "tls" then Orderer and Peers are launched with TLS enabled
# By default the TLS is DISABLED

DOCK_FOLDER=$PWD

./clean.sh all

cd config

cryptogen generate --config=../raft/crypto-config.yaml

export FABRIC_CFG_PATH=$PWD/../raft

configtxgen -outputBlock  ./orderer/airlinegenesis.block -channelID ordererchannel  -profile AirlineOrdererGenesis


echo    "====>Generating the channel create tx"
configtxgen -outputCreateChannelTx  airlinechannel.tx -channelID airlinechannel  -profile AirlineChannel

cd $DOCK_FOLDER
echo "********************* Launching with TLS RAFT *******************"
docker-compose -f ./config/docker-compose-base.yaml -f ./tls/docker-compose-tls.yaml -f ./raft/docker-compose-raft.yaml up -d

sleep 10s

. bins/set-context.sh acme raft
. bins/submit-channel-create.sh
. bins/join-channel.sh
. bins/anchor-update.sh

. bins/set-context.sh budget raft

. bins/join-channel.sh 

sleep 10s 
. bins/anchor-update.sh

#./bins/set-context.sh   acme   $1


